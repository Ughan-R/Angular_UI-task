import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatExpansionModule } from '@angular/material/expansion';

interface BillingInfo {
  name: string;
  companyName: string;
  email: string;
  vatNumber: string;
}

interface Invoice {
  date: string;
  id: string;
  amount: number;
  pdf: string;
}

interface Transaction {
  name: string;
  date: string;
  amount: number;
  type: 'credit' | 'debit';
  status: 'up' | 'down';
  isOpen: true | false ;
}

@Component({
  selector: 'app-billing',
  imports: [CommonModule,MatExpansionModule],
  templateUrl: './billing.html',
  styleUrl: './billing.scss',
})
export class Billing {
  billingInfo: BillingInfo[] = [
    {
      name: 'Oliver Liam',
      companyName: 'Viking Burrito',
      email: 'oliver@burrito.com',
      vatNumber: 'FRB1235476'
    },
    {
      name: 'Lucas Harper',
      companyName: 'Stone Tech Zone',
      email: 'lucas@stone-tech.com',
      vatNumber: 'FRB1235476'
    },
    {
      name: 'Ethan James',
      companyName: 'Fiber Nation',
      email: 'ethan@fibre.com',
      vatNumber: 'FRB1235476'
    }
  ];

  selectedbillinginfo:any = {};

  invoices: Invoice[] = [
    { date: 'March,01,2020', id: 'CL_7483947', amount: 180 ,pdf:'/examplejsnotes.pdf'},
    { date: 'February,10,2021', id: '#RV_126749', amount: 250 ,pdf:'/examplejsnotes.pdf'},
    { date: 'April,05,2020', id: '#QW-103578', amount: 120 ,pdf:'/examplejsnotes.pdf'},
    { date: 'April,05,2020', id: '#AR-803481', amount: 300 ,pdf:'/examplejsnotes.pdf'}
  ];

  newestTransactions: Transaction[] = [
    { name: 'Netflix', date: '27 March 2020,at 12.30 PM', amount: 2500, type: 'debit', status: 'down', isOpen :false },
    { name: 'Apple', date: '27 March 2020,at 4.30 AM', amount: 2000, type: 'credit', status: 'up',isOpen :false }
  ];

  olderTransactions: Transaction[] = [
    { name: 'Stripe', date: '26 March 2020,at 3.45 PM', amount: 750, type: 'credit', status: 'up' ,isOpen :false},
    { name: 'Hubspot', date: '26 March 2020,at 12.30 PM', amount: 1000, type: 'credit', status: 'up' ,isOpen :false},
    { name: 'Creative Tim', date: '26 March 2020,at 8.30 PM', amount: 1500, type: 'credit', status: 'up',isOpen :false },
    { name: 'Netflix', date: '27 March 2020,at 12.30 PM', amount: 2500, type: 'debit', status: 'down' ,isOpen :false}
  ];

  toggletx(data: any){
    data.isOpen = !data.isOpen;
  }

  showinvoicepopup: boolean = false;

  popupbox() {
    this.showinvoicepopup = !this.showinvoicepopup;
    console.log(this.showinvoicepopup);
  }

  openPdf(pdfPath: string) {
  window.open(pdfPath, '_blank');
}

editoption=false;

openedit(info:any){
  this.selectedbillinginfo = {...info};
  this.editoption=true;
}
}
