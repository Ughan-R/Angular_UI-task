import { CommonModule } from '@angular/common';
import { Component, inject, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import {RouterOutlet,} from '@angular/router';
import { Login } from './login/login';
import { Loginserv } from './login/service/loginserv';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, Login,CommonModule],
  templateUrl: './app.html',
  styleUrl: './app.scss',
})
export class App {
  protected readonly title = signal('mainproject');
  
}
